Role: login_ibmcloud
=========

Login to IBM Cloud using the ibm cloud api key retrieved from the Vault

Requirements
------------

Prior to callig this role the IBM Cloud API key must be retrieved from the Vault and is set to ibmcloud_api_key

Role Variables
--------------

ibmcloud_api_key: Retrieved from IBM Vault

Dependencies
------------

None

----------------

License
-------


Author Information
------------------
